from events.models import *
from django.contrib import admin

admin.site.register([Event,EventSchedule,EventScheduleTime])
