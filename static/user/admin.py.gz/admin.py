from django.contrib import admin

from .models import *

from django.contrib import admin
from django.contrib.auth.admin import UserAdmin


admin.site.register([User,Profile,Category,UserPlans,Services,Keywords,BankDetail])
